import React, { useState, useEffect } from "react";
import "./AnimeList.css";

// Informações para usar a API do MyMemory
const EMAIL = "brun4case@gmail.com"; 
const API_KEY = "44889396387b8fba1cf5"; // Chave de API 
const LIMIT = 10; // Número de animes por página

export default function AnimeList() {
  // Estados
  const [animes, setAnimes] = useState([]); // Lista de animes
  const [page, setPage] = useState(1); // Página atual
  const [isLoading, setIsLoading] = useState(false); // Controle de carregamento

  // Função que traduz o texto usando a API MyMemory
  async function translateText(text) {
    if (!text) return "Sem sinopse disponível"; // Se não tiver sinopse
    const textoCortado = text.slice(0, 500); // Limita o texto a 500 caracteres

    try {
      const response = await fetch(
        `https://api.mymemory.translated.net/get?q=${encodeURIComponent(
          textoCortado
        )}&langpair=en|pt&de=${EMAIL}&key=${API_KEY}`
      );
      const data = await response.json();

      // Se atingir o limite gratuito de tradução, retorna o texto original
      if (
        data.responseDetails?.includes(
          "YOU USED ALL AVAILABLE FREE TRANSLATIONS"
        )
      ) {
        return textoCortado;
      }

      // Retorna o texto traduzido (ou original se der erro)
      return data.responseData.translatedText || textoCortado;
    } catch (error) {
      console.error("Erro na tradução:", error);
      return textoCortado;
    }
  }

  // useEffect roda toda vez que a página muda (ou no carregamento inicial)
  useEffect(() => {
    async function fetchAndTranslateAnimes() {
      setIsLoading(true); // Ativa o "Carregando..."

      try {
        // Busca os animes da API do Jikan (MyAnimeList)
        const response = await fetch(
          `https://api.jikan.moe/v4/anime?page=${page}&limit=${LIMIT}`
        );
        const data = await response.json();

        // Traduz cada sinopse dos animes
        const animesTraduzidos = await Promise.all(
          data.data.map(async (anime) => {
            const traducao = await translateText(anime.synopsis);
            return { ...anime, synopsis: traducao };
          })
        );

        setAnimes(animesTraduzidos); // Atualiza o estado com os animes traduzidos
      } catch (error) {
        console.error("Erro ao buscar os animes:", error);
      } finally {
        setIsLoading(false); // Finaliza o carregamento
      }
    }

    fetchAndTranslateAnimes(); // Chama a função
  }, [page]); // Executa sempre que a página muda

  return (
    <div className="anime-container">
      <h1>🌙 Lista de Animes</h1>

      {isLoading ? (
        <p className="loading">Carregando...</p>
      ) : (
        <>
          <div className="anime-list">
            {/* Lista de animes */}
            {animes.map((anime) => (
              <div key={anime.mal_id} className="anime-card">
                <img src={anime.images.jpg.image_url} alt={anime.title} />
                <h2>{anime.title}</h2>
                <p>
                  <strong>Sinopse:</strong> {anime.synopsis || "Sem sinopse"}
                </p>
                <p>
                  <strong>Episódios:</strong>{" "}
                  {anime.episodes || "Desconhecido"}
                </p>
                <p>
                  <strong>Nota:</strong> {anime.score || "Sem nota"}
                </p>
              </div>
            ))}
          </div>

          {/* Paginação */}
          <div className="pagination">
            {page > 1 && (
              <button onClick={() => setPage(page - 1)}>← Página Anterior</button>
            )}
            <button onClick={() => setPage(page + 1)}>Próxima Página →</button>
          </div>
        </>
      )}
    </div>
  );
}
